#!/bin/bash
# ============================================================
#   update-nginx.sh
#   Update /etc/nginx/nginx.conf (base config) tanpa install ulang
#   CHANELOG VPN SCRIPT
#   Aman dijalankan berkali-kali: backup otomatis + rollback
#   kalau config baru ternyata error.
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

if [[ $EUID -ne 0 ]]; then
  echo -e "${RED}[ERROR]${NC} Jalankan sebagai root!"
  exit 1
fi

if ! command -v nginx &>/dev/null; then
  echo -e "${RED}[ERROR]${NC} Nginx belum terinstall di server ini. Install dulu (apt install nginx) atau jalankan install.sh lengkap."
  exit 1
fi

echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
echo -e "  Update /etc/nginx/nginx.conf (base config)"
echo -e "${CYAN}══════════════════════════════════════════════════${NC}"

BACKUP="/etc/nginx/nginx.conf.bak.$(date +%Y%m%d%H%M%S)"

if [[ -f /etc/nginx/nginx.conf ]]; then
  echo -e "${YELLOW}[*]${NC} Backup nginx.conf lama -> $BACKUP"
  cp /etc/nginx/nginx.conf "$BACKUP"
fi

echo -e "${YELLOW}[*]${NC} Menulis nginx.conf baru..."
cat > /etc/nginx/nginx.conf <<'EOFMAIN'
user www-data;

worker_processes 1;
pid /var/run/nginx.pid;

events {
	multi_accept on;
  worker_connections 1024;
}

http {
	gzip on;
	gzip_vary on;
	gzip_comp_level 5;
	gzip_types    text/plain application/x-javascript text/javascript application/octet-stream text/xml text/css application/protobuf application/vnd.android.package-archive application/binary application/zip application/json application/javascript application/x-www-form-urlencoded application/geo+json application/manifest+json application/x-web-app-manifest+json text/cache-manifest text/x-component text/x-cross-domain-policy;

	autoindex on;
  sendfile on;
  tcp_nopush on;
  tcp_nodelay on;
  charset UTF-8;
  source_charset UTF-8;
  charset_types text/plain application/octet-stream text/javascript application/json;
  keepalive_timeout 165;
  types_hash_max_size 2048;
  server_tokens off;
  include /etc/nginx/mime.types;
  default_type application/octet-stream;
  access_log /var/log/nginx/access.log;
  error_log /var/log/nginx/error.log;
  client_max_body_size 32M;
	client_header_buffer_size 8m;
	large_client_header_buffers 8 8m;

	fastcgi_buffer_size 8m;
	fastcgi_buffers 10 8m;

	fastcgi_read_timeout 600;

	set_real_ip_from 204.93.240.0/24;
	set_real_ip_from 204.93.177.0/24;
	set_real_ip_from 199.27.128.0/21;
	set_real_ip_from 173.245.48.0/20;
	set_real_ip_from 103.21.244.0/22;
	set_real_ip_from 103.22.200.0/22;
	set_real_ip_from 103.31.4.0/22;
	set_real_ip_from 141.101.64.0/18;
	set_real_ip_from 108.162.192.0/18;
	set_real_ip_from 190.93.240.0/20;
	set_real_ip_from 188.114.96.0/20;
	set_real_ip_from 197.234.240.0/22;
	set_real_ip_from 198.41.128.0/17;
	real_ip_header     CF-Connecting-IP;

  include /etc/nginx/conf.d/*.conf;
  add_header 'Access-Control-Expose-Headers' 'Content-Lenght,Content-Range';
  add_header Strict-Transport-Security "max-age=999999999; includeSubDomains; preload";
}
EOFMAIN

echo -e "${YELLOW}[*]${NC} Testing konfigurasi (nginx -t)..."
if nginx -t 2>/tmp/nginx_test_err.txt; then
  systemctl reload nginx
  echo -e "${GREEN}[OK]${NC} nginx.conf berhasil diupdate & nginx sudah di-reload."
  echo -e "${GREEN}[OK]${NC} Backup versi lama ada di: $BACKUP"
else
  echo -e "${RED}[GAGAL]${NC} Konfigurasi baru error, rollback ke versi sebelumnya..."
  cat /tmp/nginx_test_err.txt
  if [[ -f "$BACKUP" ]]; then
    cp "$BACKUP" /etc/nginx/nginx.conf
    systemctl reload nginx 2>/dev/null
    echo -e "${YELLOW}[INFO]${NC} Rollback selesai, nginx.conf dikembalikan ke versi sebelumnya."
  fi
  exit 1
fi

echo -e "${CYAN}══════════════════════════════════════════════════${NC}"
